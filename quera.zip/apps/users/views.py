from django.shortcuts import render
from django.views.generic import CreateView,UpdateView

from apps.users.forms import RegisterForm


class RegisterView(CreateView):
    form_class = RegisterForm
    template_name = ""
# Create your views here.
